import React from "react";
import Form from "./Componenets/Form";
import Form1 from "./Componenets/Form1";

const Account = () => {
  return (
    <div>
      <Form />
      <Form1 />
    </div>
  );
};

export default Account;
