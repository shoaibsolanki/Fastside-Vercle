import React from "react";

const Faq = () => {
  return <div>F</div>;
};

export default Faq;
